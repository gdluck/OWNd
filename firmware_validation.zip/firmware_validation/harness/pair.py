# Pairs each command (TAG.cl) with the bus frames the program sent (TAG.stub, RX *03* lines) and the
# monitor events (TAG.mon) that followed it before the next command. Output TAG.tsv:
# command <TAB> reply <TAB> bus frames (hex bodies, '+'-joined, '-' if none) <TAB> monitor output
import re,sys
tag=sys.argv[1]; import os; O=os.environ.get('RESULTS', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')) + '/'
cl=[];
for l in open(O+tag+'.cl'):
    m=re.match(r'([\d.]+) CMD (\S+) -> (.*)',l.strip())
    if m: cl.append((float(m.group(1)),m.group(2),m.group(3)))
    m=re.match(r'([\d.]+) DONE',l.strip())
    if m: cl.append((float(m.group(1)),'DONE',''))
    m=re.match(r'([\d.]+) NOCONN (\S+)',l.strip())
    if m: cl.append((float(m.group(1)),m.group(2),'NOCONN'))
rx=[]
for l in open(O+tag+'.stub'):
    m=re.match(r'([\d.]+) RX (.*)',l.strip())
    if m:
        for f in re.findall(r'\*03\*\d+\*\d+\*\$(?:0[3-6]|1[78])([0-9A-Fa-f]+)#',m.group(2)): rx.append((float(m.group(1)),f))
mon=[]
try:
    for l in open(O+tag+'.mon'):
        m=re.match(r'([\d.]+) (.*)',l.strip())
        if m: mon.append((float(m.group(1)),m.group(2)))
except FileNotFoundError: pass
def rep(r):
    if "*#*1##" in r: return 'ACK'
    if "*#*0##" in r: return 'NACK'
    if r=="b''": return 'silent'
    return r
with open(O+tag+'.tsv','w') as out:
    for i,(t,c,r) in enumerate(cl):
        if c=='DONE': break
        t2=cl[i+1][0] if i+1<len(cl) else t+5
        fr=[f for (tf,f) in rx if t<=tf<t2]
        ev=[e for (te,e) in mon if t<=te<t2]
        out.write("%s\t%s\t%s\t%s\n"%(c,rep(r),' + '.join(fr) if fr else '-',' '.join(ev) if ev else ''))
