# Sends each command line to the program's OWN port, one at a time, and logs timestamp, command and reply.
import socket,time,sys
port=int(sys.argv[1]); cmds=[l.strip() for l in open(sys.argv[2]) if l.strip() and not l.startswith('#')]
out=open(sys.argv[3],'w'); pause=float(sys.argv[4])
for cmd in cmds:
    s=None
    for a in range(10):
        try: s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",port)); break
        except Exception: s.close(); s=None; time.sleep(1)
    t=time.time()
    if s is None: out.write("%.3f NOCONN %s\n"%(t,cmd)); out.flush(); continue
    r=b''
    try:
        s.sendall(cmd.encode()); r=s.recv(300)
    except Exception: pass
    try: s.close()
    except Exception: pass
    out.write("%.3f CMD %s -> %r\n"%(t,cmd,r)); out.flush()
    time.sleep(pause)
out.write("%.3f DONE\n"%time.time()); out.flush()
