#!/bin/bash
cd ${WORK:-$PWD}
R() { docker run --rm --platform linux/arm/v7 -v ${WORK:-$PWD}:/work "$@" arm32v7/gcc:10 bash /work/oracle3/run.sh > /dev/null 2>&1; }
for ROOT in f454 F459 f461 F450; do
  R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=bt_device -e P=30013 -e M=31013 -e TAG=dev_$ROOT -e PAUSE=1.5 &
done
wait
cd oracle3 && for ROOT in f454 F459 f461 F450; do python3 pair.py dev_$ROOT; done
echo BATCH4 DONE
