# Runs inside arm32v7/gcc:10 with ${WORK:-$PWD} mounted at /work.
# env: ROOT (rootfs dir under /work) BIN P M TAG PAUSE CFG(stack_open_migrated.xml|stack_open.xml) ARGS COSO=1
cd /work/$ROOT || exit 1
O=/work/oracle3/out
mkdir -p var/tmp/bticino/bt_wd tmp log 2>/dev/null||true
if [ -f home/bticino/cfg/${CFG:-stack_open_migrated.xml} ]; then
  sed 's#<logverbosity>0</logverbosity>#<logverbosity>6</logverbosity>#g' home/bticino/cfg/${CFG:-stack_open_migrated.xml} > var/tmp/stack_open.xml
fi
: > var/tmp/BTicino.log
export LD_LIBRARY_PATH=/lib:/usr/lib:/home/bticino/lib:/home/bticino/libcoso
SLOG=$O/$TAG.stub python3 -u /work/oracle3/stub.py &
sleep 1
if [ -n "$COSO" ]; then
  sed 's/LogLev=0/LogLev=7/' home/bticino/cfg/coso_cfg > /tmp/cc; cp /tmp/cc home/bticino/cfg/coso_cfg
  for f in home/bticino/cfg/coso_plugins/*; do sed -i 's/LogLev=0/LogLev=7/' $f; done
  ( cd /work/$ROOT/home/bticino; while [ ! -f /tmp/done ]; do chroot /work/$ROOT /home/bticino/bin/coso -c /home/bticino/cfg/coso_cfg -d /home/bticino/libcoso -p /home/bticino/cfg/coso_plugins -F /var/tmp -f coso.log -l 7 -y file >> $O/$TAG.prog 2>&1; sleep 1; done ) &
else
  ( while [ ! -f /tmp/done ]; do chroot /work/$ROOT /home/bticino/bin/$BIN ${ARGS:--s 20001 -p $P -m $M} >> $O/$TAG.prog 2>&1; sleep 1; done ) &
fi
sleep 3
python3 -u /work/oracle3/mon.py $M $O/$TAG.mon &
sleep 2
python3 -u /work/oracle3/client.py $P /work/oracle3/$TAG.cmds $O/$TAG.cl ${PAUSE:-1.5}
sleep 4
touch /tmp/done
cp var/tmp/BTicino.log $O/$TAG.log 2>/dev/null; cp var/tmp/coso.log $O/$TAG.coso_log 2>/dev/null
pkill -9 -f /home/bticino/bin/ 2>/dev/null; sleep 1
