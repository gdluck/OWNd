#!/bin/bash
# Same command lists on the other firmware trees that carry the translators (f454, F459, f461, F450).
cd ${WORK:-$PWD}
R() { docker run --rm --platform linux/arm/v7 -v ${WORK:-$PWD}:/work "$@" arm32v7/gcc:10 bash /work/oracle3/run.sh > /dev/null 2>&1; }
for ROOT in f454 F459 f461 F450; do
  for B in termo luci coso spv multi dev; do
    [ -f $ROOT/home/bticino/bin/$( [ $B = termo ] && echo bt_termo || ([ $B = coso ] && echo coso || ([ $B = spv ] && echo bt_supervisione || echo bt_$B))) ] || continue
    [ -f oracle3/${B}_$ROOT.cmds ] || cp oracle3/$B.cmds oracle3/${B}_$ROOT.cmds
  done
done
for ROOT in f454 F459 f461 F450; do
  [ -f $ROOT/home/bticino/bin/bt_termo ] && [ $ROOT != f454 ] && R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=bt_termo -e P=30004 -e M=31004 -e TAG=termo_$ROOT -e PAUSE=1.5 &
  [ -f $ROOT/home/bticino/bin/bt_luci ] && R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=bt_luci -e ARGS="-s 20001 -p 30001 -P 31001" -e P=30001 -e M=31001 -e TAG=luci_$ROOT -e PAUSE=1.5 &
  [ -f $ROOT/home/bticino/bin/coso ] && R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=coso -e COSO=1 -e P=30002 -e M=31002 -e TAG=coso_$ROOT -e PAUSE=2 &
  [ -f $ROOT/home/bticino/bin/bt_supervisione ] && R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=bt_supervisione -e ARGS="-s 20001 -p 30018 -P 31018" -e P=30018 -e M=31018 -e TAG=spv_$ROOT -e PAUSE=2 &
  [ -f $ROOT/home/bticino/bin/bt_multi ] && R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=bt_multi -e ARGS="-s 20001 -p 30022 -P 31022" -e P=30022 -e M=31022 -e TAG=multi_$ROOT -e PAUSE=2 &
  [ -f $ROOT/home/bticino/bin/bt_device ] && R -e ROOT=$ROOT -e CFG=stack_open.xml -e BIN=bt_device -e P=30013 -e M=31013 -e TAG=dev_$ROOT -e PAUSE=1.5 &
  wait
done
cd oracle3 && for f in out/*_f454.cl out/*_F459.cl out/*_f461.cl out/*_F450.cl; do t=$(basename $f .cl); python3 pair.py $t; done
echo BATCH3 DONE
