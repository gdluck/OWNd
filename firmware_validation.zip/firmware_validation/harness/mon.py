import socket,time,sys
port=int(sys.argv[1]); out=open(sys.argv[2],'w')
while True:
    s=socket.socket()
    try: s.connect(("127.0.0.1",port))
    except OSError: s.close(); time.sleep(0.5); continue
    try:
        s.settimeout(1)
        while True:
            try: d=s.recv(4096)
            except socket.timeout: continue
            if not d: break
            out.write("%.3f %r\n"%(time.time(),d)); out.flush()
    except OSError: pass
    s.close(); time.sleep(0.5)
