# Fake scsserver on 127.0.0.1:20001. Logs every byte the firmware program sends with a timestamp.
# Answers the handshake with *01*01# and every *03* (frame to bus) with *01*01# (bus ACK), like oracle2/stub_tx_b.py.
import socket,threading,time,os
log=open(os.environ['SLOG'],'w'); lk=threading.Lock()
def L(s):
    with lk: log.write("%.3f %s\n"%(time.time(),s)); log.flush()
srv=socket.socket(); srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); srv.bind(("127.0.0.1",20001)); srv.listen(5)
def h(c):
    c.settimeout(0.3)
    try:
        d=c.recv(4096); L("HS %r"%d); c.sendall(b'*01*01#')
    except Exception as e: L("HSERR %s"%e)
    while True:
        try:
            d=c.recv(4096)
            if not d: L("EOF"); return
            L("RX %r"%d)
            if b'*03*' in d: c.sendall(b'*01*01#')
        except socket.timeout: pass
        except Exception as e: L("ERR %s"%e); return
while True:
    c,a=srv.accept(); threading.Thread(target=h,args=(c,),daemon=True).start()
