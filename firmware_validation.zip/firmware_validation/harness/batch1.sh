#!/bin/bash
cd ${WORK:-$PWD}
R() { docker run --rm --platform linux/arm/v7 -v ${WORK:-$PWD}:/work "$@" arm32v7/gcc:10 bash /work/oracle3/run.sh > /dev/null 2>&1; }
R -e ROOT=mhs1 -e BIN=bt_luci -e P=30001 -e M=31001 -e TAG=luci -e PAUSE=1.5 &
R -e ROOT=mhs1 -e BIN=coso -e COSO=1 -e P=30002 -e M=31002 -e TAG=coso -e PAUSE=2 &
R -e ROOT=mhs1 -e BIN=bt_supervisione -e P=30018 -e M=31018 -e TAG=spv -e PAUSE=2 &
R -e ROOT=mhs1 -e BIN=bt_multi -e P=30022 -e M=31022 -e TAG=multi -e PAUSE=2 &
R -e ROOT=mhs1 -e BIN=bt_device -e P=30013 -e M=31013 -e TAG=dev -e PAUSE=1.5 &
cp oracle3/termo.cmds oracle3/termo_f454.cmds; R -e ROOT=f454 -e CFG=stack_open.xml -e BIN=bt_termo -e P=30004 -e M=31004 -e TAG=termo_f454 -e PAUSE=1.5 &
wait
cd oracle3 && for t in luci coso spv multi dev termo_f454; do python3 pair.py $t; done
echo BATCH1 DONE
