# Compare the mhs1 result of each command with the other firmware trees: prints per program the
# commands whose (reply, bus frames) differ between trees, and a summary count.
import glob,os,sys
import os; O=os.environ.get('RESULTS', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')) + '/'
def load(t):
    d={}
    for l in open(O+t+'.tsv'):
        p=l.rstrip('\n').split('\t'); d[p[0]]=(p[1],p[2])
    return d
for prog in ['termo','luci','coso','spv','multi','dev']:
    base=load(prog); 
    for f in sorted(glob.glob(O+prog+'_*.tsv')):
        tree=os.path.basename(f)[len(prog)+1:-4]; other=load(prog+'_'+tree)
        same=sum(1 for c in base if c in other and base[c]==other[c])
        diff=[(c,base[c],other.get(c)) for c in base if other.get(c)!=base[c]]
        print(f"## {prog}: mhs1 vs {tree}: {same}/{len(base)} identical, {len(diff)} differ")
        for c,b,o in diff: print(f"   {c}\tmhs1={b}\t{tree}={o}")
