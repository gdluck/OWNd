#!/bin/bash
cd ${WORK:-$PWD}
R() { docker run --rm --platform linux/arm/v7 -v ${WORK:-$PWD}:/work "$@" arm32v7/gcc:10 bash /work/oracle3/run.sh > /dev/null 2>&1; }
R -e ROOT=mhs1 -e BIN=bt_supervisione -e ARGS="-s 20001 -p 30018 -P 31018" -e P=30018 -e M=31018 -e TAG=spv -e PAUSE=2 &
R -e ROOT=mhs1 -e BIN=bt_multi -e ARGS="-s 20001 -p 30022 -P 31022" -e P=30022 -e M=31022 -e TAG=multi -e PAUSE=2 &
wait
cd oracle3 && for t in spv multi; do python3 pair.py $t; done
echo BATCH2 DONE
