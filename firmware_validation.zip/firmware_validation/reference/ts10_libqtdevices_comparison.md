# OWNd and MyHOME messages matched against the TS10 C++ client (libqtdevices TS10_1_0_23)

Date 2026-10-07. Folder `OWNdTS10/` holds the three clones used here:

| Repo | Ref | Commit |
|---|---|---|
| OpenWebNet-HA/OWNd | default branch (master) | `c7c3a7b` (v2.0.0-b10 + 7, includes PR #82 and PR #83) |
| OpenWebNet-HA/MyHOME | `v2-phase1-architecture` | `394c028` |
| OpenWebNet-HA/libqtdevices | tag `TS10_1_0_23` | `736f41c4` |

Reference is the TS10 code: what BTicino's own touch-screen client sends and parses is taken as "what works".
Every claim cites `file:line` in these clones. Lines marked **deduction** are my inference, not a quoted fact.
Builds on `oracle2/audit/AUDIT_MyHOME_OWNd.md` (firmware sweep, 2026-10-02) and `reviews/OWNd_PR82_review.md`
(2026-10-06); those are not repeated, only referenced as **FW** (firmware sweep) and **PR82 review**.

How TS10 builds frames (used throughout): `createCommandFrame` = `*WHO*WHAT*WHERE##`, `createDimensionFrame` =
`*#WHO*WHERE*DIM##`, `createWriteDimensionFrame` = `*#WHO*WHERE*#DIM##`, `createStatusRequestFrame` = `*#WHO*WHERE##`
(`frame_functions.cpp:46-64`); `device::sendCommand(int)` and `sendRequest()` wrap them (`device.cpp:310-331`).

Verification method: I read every `*_device.cpp` in libqtdevices and the expected frames in `libqtdevices/test/*.cpp`,
every builder/parser in `OWNd/OWNd/message/*.py`, and every call site in `MyHOME/custom_components/myhome/*.py`; then I ran
OWNd's `OWNEvent.parse()` on 30 TS10 frames (python-dateutil installed in a scratch venv, nothing changed in the repos).

---

## 1. Summary

* **WHO 1, 2, 25 (dry contact), 13 (clock), 18 (meter totals / graphs / 1200 auto-update)**: the frames MyHOME actually sends
  match what TS10 sends. Differences are extra OWNd features (dimension 10 / `#11#001` shutters, HSV, colour temperature, PIR,
  blink) that TS10 does not have, and TS10 features OWNd lacks (fixed timing 11-18, variable timing write, dimmer 10 presets 2-10,
  30/31 step commands, thresholds 516/517).
* **WHO 4**: after PR #82/#83 the central and zone commands agree with TS10 (303 / 1 / 0 / 302 / 311 / `#14*TTTT*3`, fan on the plain
  zone, `*4*311*#Z##`). Remaining mismatches: the mode digit in `#14` writes (OWNd sends 1 or 2, TS10 always 3),
  WHAT 0/1 on a zone read as heat/cool instead of "zone back to automatic", `115#PPPP` / `215#PPPP` read as a temperature instead
  of a program number, holiday 13xxx/23xxx read as "auto", dimension 13 `3` (no leading zero) read as unknown, WHAT 30/31
  (malfunction / battery) unnamed. Details in §3.
* **WHO 22 sound diffusion**: TS10 uses WHO 22 only (`media_device.cpp`); OWNd and MyHOME use WHO 16 only. Not one frame matches.
  This is the biggest gap (FW A9 said the same from the mhs1 side).
* **WHO 5 alarm**: TS10 arms with `*5*36#password*0##` and partialises with `*5*50#password#mask*0##`; OWNd only has 1/2/8/9/17
  builders, which TS10 never sends. MyHOME only polls (`*#5*0##`, which matches).
* **WHO 0 scenario, WHO 8 video door entry + messages, WHO 18 load control (71-75) and Stop&Go (21-29, 212, 250), WHO 4 BACnet
  (dim 50-53) and advanced split (dim 22), WHO 13 LAN / PIC / DNS**: TS10 has full device classes; OWNd parses them generically
  or not at all and has no builders. MyHOME does not use them.
* **OWNd-only subsystems** with no TS10 counterpart at all: WHO 7 (`OWNAVCommand`), WHO 15 CEN, WHO 17 scenes, WHO 14 (used by
  MyHOME button), WHO 1013 (MyHOME gateway model probe), WHO 16.
* **PR82 review doubts**: all four are now closed in OWNd master / MyHOME (see §6).

---

## 2. Per-WHO match tables

Column "MyHOME" names the file that sends the frame; "—" means MyHOME never sends it. Verdict: **=** identical frame,
**≈** same frame with a documented difference, **✗** mismatch, **TS10 only**, **OWNd only**.

### 2.1 WHO 1 lighting (`lighting_device.cpp`, `OWNd/message/lighting.py`, MyHOME `light.py`, `switch.py`, `light_group.py`)

| Function | TS10 frame | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| status | `*#1*W##` (`lighting_device.cpp:126-129`, test `:123`) | `status()` `*#1*W##` (`lighting.py:300-303`) | `light.py`, `switch.py`, `gateway_resync.py` | = |
| on / off | `*1*1*W##`, `*1*0*W##` (`:100-108`) | `switch_on/off` (`:392-409`) | `light.py:883,929` | = |
| on / off with speed (dimmer 100) | `*1*1#speed*W##`, `*1*0#speed*W##` (`:399-407`, test `:237-238`) | `switch_on(where, transition)` (`:393-395`, 403-405) | `light.py:876,916` | = |
| set level (dimmer 100) | `*#1*W*#1*{100+level}*speed##` (`:419-422`, test `:440`) | `set_brightness` same (`:420-422`) | `light.py:843-849` | = |
| set level 0 | TS10 sends `*#1*W*#1*100*speed##` unguarded (`:421`; test `:444` only checks the *reply* is read as off) | `set_brightness(0)` → `switch_off` (`:416-419`) | `light.py:623` | ≈ OWNd deliberately avoids 100 (FW A7: refused) |
| level request (dimmer 100) | `*#1*W*1##` (`:424-427`) | `get_brightness` (`:306-309`) | `light.py` | = |
| dimmer 10 set level | `*1*{2..10}*W##` via `dimmer100LevelTo10` (`:240-245`, `:63-85`) | **no builder**; parser maps 2-10 to `brightness_preset` (`:60-63`) | — | TS10 only |
| dimmer step up / down | `*1*30*W##`, `*1*31*W##` (`:230-238`) | **no builder**; parser logs "dimmed up/down" with no level (`:91-93`) | — | TS10 only |
| dimmer 100 step | `*1*30#delta#speed*W##`, `*1*31#delta#speed*W##` (`:409-417`, test `:714`) | parser ignores delta (same branch `:91-93`); no builder | — | TS10 only |
| fixed timing | `*1*{11..18}*W##` (`:110-117`) | **no builder**; parser maps 11-18 to seconds (`:64-87`) | — | TS10 only |
| variable timing write | `*#1*W*#2*h*m*s##` (`:119-124`, test `:88`) | **no builder**; parser reads dim 2 (`:121-127`) | — | TS10 only |
| variable timing request | `*#1*W*2##` (`:131-134`) | **no builder** | — | TS10 only |
| blink 20-29 | not in TS10 | `flash()` (`:373-389`) | `light.py:726-729,922-925` | OWNd only (FW C: accepted) |
| PIR / illuminance / timeout dims 5, 6, 7 | not in TS10 | `:312-327` | `binary_sensor.py:589-590`, `sensor.py:852` | OWNd only |
| HSV dim 12, colour temp dim 14 | not in TS10 | `:330-370` | `light.py`, `light_group.py` | OWNd only |
| parse `*1*1#x*W##` (one arg) | handled as dimmer-100 on/off only when advanced (`:176-178`, `:445-446`) | state 1 for any device | — | ≈ harmless |
| parse dim 1 reply level 100 | → off (`:363-369`) | → off (`:115-117`) | | = |

### 2.2 WHO 2 automation (`automation_device.cpp`, `OWNd/message/automation.py`, MyHOME `cover.py`)

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| up / down / stop | `*2*1*W##`, `*2*2*W##`, `*2*0*W##` (`:48-61`, test `:50-66`) | `raise/lower/stop_shutter` (`:147-168`) | `cover.py:897-899` | = |
| status | `*#2*W##` (`:63-66`) | `status()` (`:133-138`) | `cover.py` | = |
| parse | only WHAT 0/1/2 (`:73-83`) | 0/1/2 + 10-14 + dimension 10 (`:23-96`) | | OWNd superset |
| advanced status | not in TS10 | `*#2*W*10##` (`:141-144`) | `cover.py:876-878` | OWNd only (FW C: accepted) |
| set position | not in TS10 | `*#2*W*#11#001*L##` (`:171-174`) | `cover.py:945-955` | OWNd only (FW C: L 0-100) |

### 2.3 WHO 25 dry contact / CEN+ (`automation_device.cpp:86-115`, `scenario_device.cpp:159-186`, `OWNd/message/cen.py`)

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| PPTStat status | `*#25*W##` (`:96-99`, test `:107`) | `OWNDryContactCommand.status` (`cen.py:160-163`) | `binary_sensor.py:441` | = |
| PPTStat parse | WHAT 31 → closed/true, 32 → false; `#x` arg ignored (`:101-115`, test `:114-117`) | 31 → on, 32 → off, arg = detection (`:47-67`) | | = |
| ScenarioPlus on / off / inc / dec / stop | `*25*11#0*W##`, `*25*12*W##`, `*25*13#0#5*W##`, `*25*14#0#5*W##`, `*25*15*W##` (`scenario_device.cpp:37-41`, `:163-186`) | **no builder**; parser returns bare `OWNEvent` for WHAT 11-15 (`cen.py:283-284`, verified: `*25*11#0*1##` → `OWNEvent`) | — | TS10 only |
| CEN+ 21-28 | not in TS10 | `OWNCenPlusCommand` (`cen.py:231-268`) | — | OWNd only (FW C) |

### 2.4 WHO 4 thermoregulation

Central unit (`thermal_device.cpp`; TS10 WHERE is `#`+where, `:87`; 99-zone where `0` → `#0`, 4-zone where `1#2` → `#1#2`,
`test_thermal_device.h:27-28`). OWNd `heating.py`, MyHOME `climate.py`.

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| central status | `*#4*#W##` (`:91-94`) | `status("#0")` (`heating.py:712-715`) | `climate.py:416` | = |
| off | `*4*303*#W##` (`:101-104`, test `:46`) | `set_central_mode(off)` 303 (`:897-908`) | `climate.py:527` | = |
| summer / winter | `*4*0*#W##`, `*4*1*#W##` (`:111-119`, test `:54,62`) | cool → 0, heat → 1 (`:899-900`) | `climate.py:527` | = |
| protection | `*4*302*#W##` (`:106-109`, test `:70`) | `protection` → 302, `antifreeze` → 102 (`:902-903`) | — | = (102 is OWNd extra, FW A1 accepted) |
| automatic on central | not sent by TS10 (311 only exists on `ControlledProbeDevice`, `probe_device.cpp:129-133`) | `set_central_mode(auto)` → `*4*311*#0##` (`:901`) | `climate.py:527` | OWNd only (FW A1: 311 accepted on `#0`) |
| manual setpoint | `*#4*#W*#14*TTTT*3##`, always mode digit 3 (`:121-137`, test `:100-102`) | `set_central_temperature` sends `*#4*#0*#14*TTTT*1##` for heat, `*2##` otherwise (`:915-927`, verified `…*0250*2##`) | `climate.py:583-591` | ✗ mode digit, see M1 |
| week program | `*4*{3100+p}*#W##` (`:139-142`, test `:92-94`) | `set_central_program` (`:930-951`) | — | = |
| scenario (99 zones) | `*4*{3200+s}*#W##` (`:412-415`) | `set_central_scenario` (`:954-975`) | — | = |
| weekend | 3 frames: `*4*315#{3100+p}*#W##`, then `*#4*#W*#30*DD*MM*YYYY##`, then `*#4*#W*#31*HH*MM##` (`:144-159`, test `:84-86`) | `set_central_weekend` + `set_holiday_end_date` + `set_holiday_end_time` (`:1008-1102`) | — | = (caller must send all three) |
| holiday | 3 frames with dummy `33002#{3100+p}` then `#30`, `#31` (`:161-178`, test `:76-78`) | `set_central_holiday(days 1..255)` (`:1032-1060`) + the two dimension writes | — | ≈ OWNd lets the caller pick the day count; TS10 always sends 2 and relies on `#30/#31` |
| timed manual (4 zones) | `*4*312#TTTT#2*#W##` then, 200 ms later, `*#4*#W*#32*HH*MM##` (`:368-392`, `:32`, test `:297-300`) | `set_timed_manual(hours 1..24)` + `set_timed_manual_end_time` (`:978-1005`, `:1105-1123`) | — | ≈ same as holiday: TS10 always sends `#2` |
| min / max setpoint | 30 .. 350 (4 z) or 400 (99 z) tenths (`:198-201`, `:394-397`, `:417-420`) | clamps 5.0 .. 40.0 °C (`:834-837`, `:920`) | | ≈ OWNd allows 5-30 °C below TS10's floor |
| parse 215/115 `#arg` | program = `whatArgN(0) % 100` (`:240-244`, `:285-289`, test `:137,161`) | `what_param[0]` read as a temperature: `*4*115#1102*#0##` → "heat at -10.2 °C" (verified; `heating.py:257-269`) | `climate.py` uses `set_temperature` | ✗ see M3 |
| parse 1100+p / 2100+p / 1200+s / 2200+s | program / scenario number exposed (`:246-256`, `:291-301`) | class only (heat / cool), number not exposed (`:210-229`) | | ≈ lossy |
| parse 13000+d / 23000+d holiday | ST_HOLIDAY with season (`:258-262`, `:303-307`, test `:144,168`) | → `auto` (`:234-236`, verified `*4*13004*#0##` → auto) | | ✗ see M4 |
| parse 21, 30, 31 | ignored on purpose (`:214-217`; 21 remote, 30 malfunction, 31 battery) | 21 named, 20 named, 30/31 → "mode is unknown" (`:243-255`, verified) | | ≈ see M5 |
| parse dims 30 / 31 / 32 | (`:313-342`) | (`:514-555`) | | = |

Zone probe (`probe_device.cpp`; `ControlledProbeDevice` WHERE is `#`+where e.g. `#23#1`, plain `simple_where` 23, `:104-118`).

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| zone status | `*#4*#23#1##` (99 z only) + `*#4*23##` (`:164-173`, test `:154`) | `status(where)` (`:712-715`) | `climate.py:416` with `_full_where` | = (MyHOME sends one of the two) |
| fancoil status | `*#4*23*11##` plain zone (`:155-162`, test `:146`) | `get_fan_speed` and MyHOME's raw parse (`:755-777`) | `climate.py:423` | = |
| manual setpoint | `*#4*#23#1*#14*TTTT*3##`, always 3 (`:120-127`, test `:125`) | `set_temperature(mode)` → `*#4*#23*#14*TTTT*1##` heat, `*2##` cool, `*3##` auto (`:841-848`, verified) | `climate.py:558-623` sends heat → 1, cool → 2 | ✗ see M1 |
| automatic | `*4*311*#23#1##` (`:129-133`, test `:132`) | `set_mode(auto)` forces `#` (`:791-795`, verified `*4*311*#23##`) | `climate.py:551` | = (PR82 doubt 2.4 closed) |
| off | `*4*303*#23#1##` (`:135-138`) | `set_mode(off)` keeps the caller's form: standalone → `*4*303*23##` (`:146-149`, verified) | `climate.py:543` | ≈ FW A3: both forms work |
| protection | `*4*302*#23#1##` (`:140-143`) | `set_mode(protection)` 302, `antifreeze` 102, `thermal_protection` 202 (`:801-806`) | — | = |
| fan speed | `*#4*23*#11*S##` plain zone, no range check (`:145-153`, test `:139`) | `set_fan_speed` 1..99 / 0..3 (`:855-881`) | `climate.py:491-501` catches `ValueError` | = (PR82 doubt 2.3 closed) |
| internal probe | `*#4*Z*0##` (`:73-76`, test `:52`) | `get_temperature` (`:724-727`) | `sensor.py:748` | = |
| external probe | `*#4*Z*15#1##` (`:75`, test `:88`) | `get_probe_temperature(where, sensor)` (`:730-752`) | `sensor.py:744-746` (no sensor arg → `*#4*Z*15##`) | ≈ MyHOME sends the bare form TS10 never sends |
| parse 110/210/310, 111/211/311 | manual / auto, only when not locally off/protected (`:208-221`) | 310/311 → auto, 110/111 → heat, 210/211 → cool (`:204-242`) | | ≈ OWNd mixes mode and season |
| parse WHAT 0 / 1 command on a zone | `CONDITIONING`/`HEATING` → status **AUTO** and re-ask central (`:240-253`) | → `cool` / `heat` mode (verified `*4*0*23##` → cool) | `climate.py:765-781` sets `hvac_mode` HEAT / COOL | ✗ see M2 |
| parse 102 on `#…` where | skipped (`:222-224`) | → off | | ≈ |
| parse dim 13 | `st<=3` → offset st, `11..13` → negative, 4 off, 5 protection, int compare (`:284-307`, test `:212-234`) | string compare: `"01".."03"` ok, bare `"3"` → `unknown` (`:349-366`, verified) | `climate.py` | ✗ see M6 |
| parse dim 12 | setpoint minus `local_offset*10` (`:279-283`) | raw value as `local_set_temperature` (`:336-344`) | `climate.py:745` | ≈ |
| parse dim 14, 0, 11 | (`:270-278`) | (`:271-286`, `:316-334`, `:373-381`) | | = |
| dims 7, 19, 20, 60, 5 | not in TS10 | parsed | | OWNd only (FW B) |

Advanced split and BACnet (TS10 only, no OWNd counterpart): `*#4*W*22##` request and `*#4*W*#22*mode*temp*vel*swing##` write
(`airconditioning_device.cpp:65-113`, test `:98-113`); WHO 0 scenario frames for basic splits (`:32-56`); BACnet dimensions
50 / 51 / 52 / 53 request and write (`bacnet_device.cpp:39,56,242,301,447,481,586,614`; `bacnet_device.h:139,357,593,758`).
OWNd parses `*#4*1*22*3*123*1*1##` as a typeless `OWNHeatingEvent` (verified).

### 2.5 WHO 18 energy (`energy_device.cpp`, `loads_device.cpp`, `stopandgo_device.cpp`; `OWNd/message/energy.py`; MyHOME `sensor.py`, `services.py`)

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| instant power | `*#18*W*113##` (electricity; 1134 water/gas, 1130, 1132 other modes) (`:41-48`, `:223-247`) | parser dim 113 only (`:53-55`); no request builder | — (relies on 1200 stream) | ≈ |
| auto-update start / stop | `*#18*W*#1200#type*255##` / `*0##`, type 1 electricity, 2 gas, 3 heat, 4 water (`:249-259`, `:50-56`, test `:855-878`) | `start_sending_instant_power(where, duration ≤255)` → `*#18*W*#1200#1*dur##` (`:212-219`) | `sensor.py:538` | = for electricity |
| auto-update reply | `*#18*W*1200#type*time##` handled (`:719-726`, test `:895-905`) | **not parsed** (verified typeless) | — | TS10 only |
| 1200 request | TS10 never sends `*#18*W*1200##` | — | `sensor.py:512`, `services.py:163` send `*#18*W*1200##` | MyHOME only, **deduction**: a status read TS10 does not use |
| today / this month | `*#18*W*54##`, `*#18*W*53##` (`:396-402`, `:548-553`) | `get_partial_daily/monthly_consumption` (`:237-243`, `:266-272`) | `sensor.py:617-621` | = |
| grand total | `*#18*W*51##`, TS10 notes 51 is the grand total not the year (`:404-409`) | `get_total_consumption` (`:284-290`) | `sensor.py:613`, `services.py:163` | = |
| month of year | `*#18*W*52#YY#M##` (`:556-557`, test `:226`) | `get_monthly_consumption` (`:275-281`) | — | = |
| day graph (hourly) | old PIC: `*#18*W*511#M#D##`; new: `*18*57#M#D*W##` (`:500-508`, test `:191`) | `get_hourly_consumption` → `*#18*W*511#M#D##` (`:222-234`) | — | = old-PIC form |
| month graph (daily, 32 bit) | old PIC: `*#18*W*513#M##`; new: `*18*59#M*W##` (`:538-546`) | `get_daily_consumption` → `*18*59#M*W##` for ≤1 year (`:257`) | — | = new form |
| previous year month graph | TS10 has no `*18*510#M*W##`; 510 is only an 8-bit dimension request `*#18*W*510#M##` (`:528-536`, test `:137`) | `*18*510#M*W##` for 1-2 years back (`:259`) | — | ✗ see M9 |
| parse 511 / 513 / 514 | (`:639-656`, `:1019-1033`) | (`:57-132`) | | = |
| 8-bit graphs 53#M, 56#M#D, 57#M, 510#M, 512#M, 58#M | (`:448-535`) | not built, not parsed | — | TS10 only (legacy) |
| thresholds | `*#18*W*516##`, `*#18*W*517#N##`, write `*#18*W*#517#N*V##` (`:568-581`, test `:270-278,1120`) | none (verified typeless) | — | TS10 only |
| WHERE | plain meter address; MyHOME/OWNd add `#0` for `7N` | OWNd `7N#0` (`:215`) | | = (FW C) |
| load control (actuators) | `*18*73*W##` enable, `*18*74*W##` force on, `*18*73#t*W##` force off, `*18*75#N*W##` reset, `*#18*W*71##`, `72#N`, `73` (`loads_device.cpp:63-112`, test `:49-97`) | none (WHO 18 event with no type) | — | TS10 only |
| Stop&Go | `*18*21..29*W##`, `*#18*W*250##` 13-bit status, `*#18*W*#212*days##`, `*#18*W*212##` (`stopandgo_device.cpp:70-178`, test `:51-246`) | none | — | TS10 only |

### 2.6 WHO 5 burglar alarm (`antintrusion_device.cpp`, `OWNd/message/alarm.py`, MyHOME `alarm_control_panel.py`)

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| status | `*#5*0##` (`:123-126`, test `:75`) | `status("0")` (`alarm.py:232-249`) | `alarm_control_panel.py:180` | = |
| arm / disarm (toggle) | `*5*36#password*0##` (`:84-87`, test `:45`) | **no builder**; parser: "unknown state '36'" (verified) | — | TS10 only, see M7 |
| partialisation | `*5*50#password#ZZZZZZZZ*0##` (`:89-96`, test `:57`) | none | — | TS10 only |
| arm 1, disarm 2, engage 8, disengage 9, panic 17 as commands | never sent by TS10 (only parsed: 8/9 `:135-142`) | builders `:252-317` (docstring already says gateways reject them) | — | OWNd only |
| parse 8 / 9 | inserted / not inserted on where `0` (`:135-142`) | engage / disengage (`:64-67`) | | = |
| parse 11 / 18 zone, 12 / 13 / 15 / 16 / 17 alarms on `#zone` | zone ranges checked (`:143-162`, tests `:124-195`) | zone from `#…` (`:26-31`), names (`:70-85`) | | = |

### 2.7 WHO 0 scenario modules (`scenario_device.cpp`, `OWNd/message/scenario.py`)

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| activate | `*0*N*W##`, N 1..31 (`:55-60`, test `:50`) | no builder (`OWNCommand.parse("*0*5*11##")` returns a bare `OWNCommand`, `base.py:391`) | — | TS10 only |
| program start / stop / delete / lock | `*0*40#N*W##`, `*0*41#N*W##`, `*0*42*W##`, `*0*42#N*W##`, `*#0*W##`; parse 43 / 44 (`:62-156`, test `:57-133`) | parser labels every WHAT as "Scenario N launched" (`scenario.py:10-25`; verified `*0*40#10*11##` → "Scenario 40 … launched") | — | ✗ see M8 |

### 2.8 WHO 9 auxiliary (`media_device.cpp:1299-1334`, `OWNd/message/scenario.py:28-98`)

`*#9*W##` request and WHAT 0/1 parse in TS10; OWNd parses 0-10 and has no builder (a raw `*9*1*7##` goes through the generic
`OWNCommand`, `base.py:393-397`). MyHOME documents the AUX route for arming (`alarm_control_panel.py:125`). Verdict =.

### 2.9 WHO 13 gateway / platform (`platform_device.cpp`, `OWNd/message/gateway.py`)

| Function | TS10 | OWNd | MyHOME | Verdict |
|---|---|---|---|---|
| set time | `*#13**#0*HH*MM*SS**##` (empty timezone field) (`:55-60`, test `:103,122`) | `*#13**#0*HH*MM*SS*TZ##` (`:268-278`) | `services.py` | ≈ OWNd fills the timezone |
| set date | `*#13**#1*00*DD*MM*YYYY##` (weekday `00`) (`:62-67`, test `:96,128`) | `*#13**#1*0w*DD*MM*YYYY##` (weekday filled) (`:260-265`) | — | ≈ |
| set date-time | `*#13**#22*HH*MM*SS**00*DD*MM*YYYY##` (`:69-74`, test `:136`) | `*#13**#22*HH*MM*SS*TZ*0w*DD*MM*YYYY##` (`:245-257`) | `services.py` | ≈ |
| requests | 9 status, 10 ip, 11 netmask, 12 mac, 16 fw, 20 pic, 23 kernel, 50 gw, 51/52 dns (`:89-143`) | parses 0, 1, 10, 11, 12, 15, 16, 19, 22, 23, 24 (`:69-171`); 9, 20, 50-52 unparsed (verified) | OWNd sends `*#13**15##` (`command_session.py:73`), keepalive `*#13**0##` (`session.py:45`); MyHOME `*#13**0/15/16##` (`services.py:169-171`) | ≈ 15, 19, 24 are OWNd-only; 9, 20, 50, 51, 52 TS10-only |
| LAN enable | `*#13**#9*v##` (`:76-87`) | none | — | TS10 only |

### 2.10 Sound diffusion: TS10 WHO 22 versus OWNd / MyHOME WHO 16 (`media_device.cpp`, `OWNd/message/sound.py`, MyHOME `media_player.py`, `sound_source.py`)

TS10 addresses: source `2#S` (`:308-313`), amplifier `3#area#point`, area `4#area`, general `5#3#0#0` (`:766-776`).

| Function | TS10 (WHO 22) | OWNd / MyHOME (WHO 16) | Verdict |
|---|---|---|---|
| amplifier on / off | `*22*34#4#area*3#A#P##`, `*22*0#4#area*3#A#P##` (`:830-838`) | `*16*3*EA##`, `*16*13*EA##` (`sound.py:134-143`; `media_player.py:621-623`) | ✗ |
| volume up / down | `*22*3#1*3#A#P##`, `*22*4#1*3#A#P##` (`:840-848`) | `*16*1001*EA##`, `*16*1101*EA##` (`:195-205`) | ✗ |
| set volume | `*#22*3#A#P*#1*vol##` (`:850-853`, test `:622`) | `*#16*EA*#1*vol##` 0..100 (`:208-216`); MyHOME scales 0..31 (`media_player.py:775-776`) | ✗ |
| amplifier status / volume request | `*#22*3#A#P*12##`, `*#22*3#A#P*1##` (`:820-828`, test `:581,643`) | `*#16*EA*5##` (`:127-131`) | ✗ |
| source on in area | `*22*35#4#area#S*3#area#0##` (`:346-351`) | `*16*3*10S##` + `*16*3*1ES##` (`:146-186`) | ✗ |
| next / previous track | `*22*9*2#S##`, `*22*10*2#S##` (`:326-334`) | `*16*6001*10S##`, `*16*6101*10S##` (`sound_source.py:220-224`) | ✗ |
| frequency up / down | `*22*5#v*2#S##`, `*22*6#v*2#S##` (`:511-549`) | `*16*5000*10S##`, `*16*5100*10S##` (`sound_source.py:228-232`) | ✗ |
| save / set station | `*22*33#st*2#S##`, `*#22*2#S*#6*st##` (`:551-559`) | `*#16*10S*#7*st##` (`sound_source.py:265`) | ✗ |
| RDS start / stop | `*22*31*2#S##`, `*22*32*2#S##` (`:566-595`) | `*16*101*10S##`, `*16*102*10S##` (`sound_source.py:194`) | ✗ |
| frequency / track / RDS / status / active-areas requests | dims 5, 6, 10, 12, 13 on `2#S` (`:364-372`, `:561-564`, test `:255-443`) | `*#16*10S*6##`, `7`, `8` (`sound_source.py:201`) | ✗ |
| power amplifier treble / bass / balance / preset / loud | dims 2, 4, 17, 19, 20; commands 40/41, 36/37, 42/43 `#1`, 55/56; writes `#19*p`, `#20*1/0` (`:1213-1296`, test `:898-975`) | none | TS10 only |
| init frame for virtual source / amplifier | `*#22*7*#15*…##` (`:715-734`) | none | TS10 only |
| OWNd parse of any WHO 22 frame | | bare `OWNEvent` (verified on `*#22*2#1*12*1*4##`, `*#22*3#1#1*1*20##`) | ✗ |

MyHOME `DISCOVERY_REQUESTS` sends `*#16*0*5##` (`gateway.py:186-190`); TS10 sends no WHO 16 frame at all.

### 2.11 WHO 8 video door entry and messages (TS10 only)

TS10 sends `*8*37#type*W##` at start-up (`videodoorentry_device.cpp:85-96`), lock 19/20 and stair light 21/22
(`:65-83`, test `:130-166`), call / answer / end `*8*1#kind#mmtype#W*target##`, `*8*2#kind#mmtype*W##`,
`*8*3#kind#mmtype*4W##` (`:139-247`), camera `*8*4#W*target##`, cycle `*8*6#W*caller##`, moves 59-62 `#1/#2`
(`:249-299`), teleloop 76/77/78/79, and the WHO 8 message protocol 9001/9002/9012/9013-9017 (`message_device.cpp:30-44`,
`:183-202`, test `:78-233`). OWNd has no WHO 8 class: `OWNEvent.parse` returns a bare event (`base.py:360-374`) and
`OWNCommand.parse` returns None for WHO 8 (`base.py:382-399`, WHO 8 is not in the fallback lists). MyHOME does not use WHO 8.

### 2.12 OWNd / MyHOME subsystems with no TS10 counterpart

| WHO | OWNd / MyHOME | Note |
|---|---|---|
| 7 | `OWNAVCommand.receive_video` `*7*0*40xx##`, `close_video` `*7*9**##` (`sound.py:101-119`) | TS10 has no WHO 7 |
| 14 | MyHOME `*14*0*W##`, `*14*1*W##` (`button.py:314,375`) | TS10 has no WHO 14 |
| 15 | `OWNCenCommand` press / release (`cen.py:167-227`) | TS10 has no WHO 15 (FW C accepted) |
| 16 | all of §2.10 | |
| 17 | `OWNSceneEvent` (`scenario.py:101-143`) | |
| 1013 | MyHOME `*#1013*0*1##` (`gateway.py:1036`) | |
| 1, 2, 4, 5 general sweeps | `*#1*0##`, `*#2*0##`, `*#4*0##`, `*#5*0##` (`gateway.py:186-189`, `services.py:173`) | TS10 never sends a WHERE-0 general status request for WHO 1/2/4 (it polls per device, `lighting_device.cpp:126-129`); `*#5*0##` is the TS10 alarm status (`antintrusion_device.cpp:123-126`) |

---

## 3. Mismatches (same function, different wire form or meaning)

**M1 Setpoint mode digit.** TS10 writes `#14*TTTT*3` for every setpoint, zone or central (`probe_device.cpp:120-127`,
`thermal_device.cpp:131-136`, tests `test_probe_device.cpp:125`, `test_thermal_device.cpp:102`). OWNd sends 1 for heat and 2 for
cool (`heating.py:841-848`, `:922`), and MyHOME takes those paths for HEAT and COOL entities (`climate.py:558-575`, `:583-591`,
`:597-613`). FW C recorded `#14` writes as accepted without saying which mode digits were swept. **Deduction**: 1/2 may force a
season on the zone where TS10's 3 keeps the plant's own; aligning on 3 is the TS10 behaviour. Low risk but a real divergence.

**M2 WHAT 0 / 1 on a zone.** TS10 treats a command `*4*0*Z##` or `*4*1*Z##` arriving for a probe as "the central is in
automatic", sets status AUTO and re-requests the central (`probe_device.cpp:240-253`); `NonControlledProbeDevice` ignores it
(`:82-83`, test `:65`). OWNd reads them as mode `cool` / `heat` (`heating.py:211-229`, verified) and MyHOME sets
`hvac_mode` COOL / HEAT (`climate.py:765-781`). **Deduction**: a zone returning to the central's program after a manual period
shows up in Home Assistant as HEAT (or COOL) instead of AUTO.

**M3 `115#PPPP` / `215#PPPP` weekend frames.** TS10 reads the argument as `program % 100` (`thermal_device.cpp:241,286`,
tests `:137,161`). OWNd reads any `what_param` on a mode WHAT as a WHO 4 temperature (`heating.py:257-269`):
`*4*115#1102*#0##` becomes "heat at -10.2 °C" (verified). MyHOME would store that as the target (`climate.py:843`).

**M4 Holiday 13xxx / 23xxx.** TS10: ST_HOLIDAY, season winter / summer, program = what − 13000 (`thermal_device.cpp:258-262`,
`:303-307`). OWNd: `auto` (`heating.py:234-236`). 33xxx is the generic command form and is also `auto` in OWNd; TS10 never
parses 33xxx (`commandRange`, `:350-358`, covers it but no case matches).

**M5 WHAT 30 / 31 from the central.** TS10 names them malfunction found and battery KO and drops them (`thermal_device.cpp:46-48`,
`:214-217`, test `:233`). OWNd logs "mode is unknown" (`heating.py:253-255`, verified). Not a defect, a missing name.

**M6 Dimension 13 without leading zero.** TS10 compares integers, so `3` and `03` are both offset +3 (`probe_device.cpp:284-307`).
OWNd compares strings and only accepts `01`-`03` and `11`-`13` (`heating.py:352-357`); `*#4*23*13*3##` is `unknown`
(verified). TS10 tests only show two-digit values (`test_probe_device.cpp:212-234`), so whether a plant emits `3` is
**not proven**; the FW audit (B, dim 13 values 7 and 8) did not list it either.

**M7 Alarm arming.** TS10 toggles with `*5*36#password*0##` and sets the zone mask with `*5*50#password#mask*0##`
(`antintrusion_device.cpp:84-96`). OWNd has `arm_*`, `disarm`, `engage`, `disengage`, `trigger` sending 1/2/8/9/17
(`alarm.py:252-317`), none of which TS10 sends; TS10 only parses 8/9 as the result (`:135-142`). MyHOME does not arm
(`alarm_control_panel.py:180` polls only), so nothing is broken today, but the OWNd builders are not the BTicino route.

**M8 WHO 0 WHAT 40-44.** TS10 parses 40/41 as programming start/stop (with or without `#N`), 43/44 as lock/unlock, and sends
`*0*40#N*W##`, `*0*41#N*W##`, `*0*42[#N]*W##` (`scenario_device.cpp:27-41`, `:62-156`). OWNd labels every WHO 0 WHAT as a
launched scenario (`scenario.py:10-25`), so `*0*40#10*11##` reads as "Scenario 40 launched" (verified). FW B already flagged
`*0*40#N*W##`…`46#N` as mislabelled; TS10 confirms the meaning of 40-44.

**M9 Energy `*18*510#M*W##`.** OWNd sends it for months 1-2 years back (`energy.py:258-259`). TS10 never sends 510 as a
command: it is the 8-bit dimension request `*#18*W*510#M##` on old PICs (`energy_device.cpp:528-536`) and the WHAT of its
reply; the two-years-back 32-bit graph is `*#18*W*514#M##` reply handling only (`:651-656`, `:115-116`), with no explicit
request in TS10 (the device answers 513 and 514 together, **deduction** from `:651`). FW D left energy requests unproven.

**M10 Auto-update reply `*#18*W*1200#type*time##`.** TS10 uses it to detect new-frame hardware and to re-arm the stream
when `time` is 0 (`energy_device.cpp:289-322`, `:719-726`). OWNd leaves it typeless (verified); MyHOME instead polls
`*#18*W*1200##` (`sensor.py:512`), a request form absent from TS10.

**M11 Clock writes.** TS10 leaves the timezone field empty and the weekday `00` (`platform_device.cpp:55-74`, tests
`:96-136`); OWNd fills both (`gateway.py:245-278`). Both forms are grammatical; which one a given gateway accepts is
**not proven** here.

**M12 WHO 16 versus WHO 22.** Every sound frame differs (§2.10). TS10 confirms FW A9 from the client side: BTicino's own
client speaks WHO 22 to amplifiers `3#A#P` and sources `2#S`.

---

## 4. OWNd / MyHOME messages with no TS10 counterpart

Commands: WHO 1 blink 20-29, dims 5/6/7/12/14 (`lighting.py:312-389`); WHO 2 dim 10 and `#11#001` (`automation.py:141-174`);
WHO 4 `set_central_mode(auto)` 311 on `#0`, `antifreeze` 102 / `thermal_protection` 202 on zones, `valves_status` 19,
bare `*#4*Z*15##`, deprecated `central_status` 14 (`heating.py:718-721`, `:747`, `:801-806`, `:901-902`, `:1126-1143`);
WHO 5 WHAT 1/2/8/9/17 commands (`alarm.py:252-317`); WHO 7 (`sound.py:101-119`); WHO 13 dims 15, 19, 24 (`gateway.py:106-170`),
`*#13**15##` (`command_session.py:73`); WHO 15 (`cen.py:167-227`); WHO 16 all (`sound.py:126-216`, `sound_source.py:194-290`);
WHO 18 `*18*510#M*W##` and `*#18*W*1200##` (`energy.py:259`, `sensor.py:512`); WHO 25 CEN+ 21-28 (`cen.py:231-268`);
MyHOME WHO 14 (`button.py:314,375`), WHO 1013 (`gateway.py:1036`), general `*#1*0##`, `*#2*0##`, `*#4*0##`, `*#16*0*5##`
(`gateway.py:186-190`).

Parsed events with no TS10 reader: WHO 4 dims 5, 7, 19, 20, 60 and WHAT 20 (`heating.py:243-247`, `:288-314`, `:400-512`,
`:557-560`); WHO 1 WHAT 34 motion (`lighting.py:94-97`); WHO 2 WHAT 10-14 / dim 10 (`automation.py:26-96`); WHO 5 WHAT 0-7,
10, 14, 26, 27, 31 (`alarm.py:48-91`); WHO 17 (`scenario.py:101-143`); WHO 9 WHAT 2-10 (`scenario.py:46-80`).

## 5. TS10 messages OWNd / MyHOME lack

Builders: WHO 1 presets 2-10, 30/31 (plain and `#delta#speed`), 11-18, `#2` write and `2` request; WHO 25 ScenarioPlus 11-15;
WHO 0 1-31, 40-42, `*#0*W##`; WHO 5 36, 50; WHO 4 dim 22 and 50-53 writes/requests, WHO 0 split scenarios; WHO 18 113/1130/1132/1134
request, 516, 517, `#517`, 8-bit graphs 53/56/57/58/510/512, loads 71-75, Stop&Go 21-29/212/250; WHO 13 9, 20, 50, 51, 52, `#9`;
WHO 22 everything; WHO 8 everything.

Parsers (typeless or wrong in OWNd): WHO 4 programme / scenario / holiday numbers, WHAT 30/31, dim 13 bare digits; WHO 0 40-44;
WHO 18 1200 reply, 516, 517, 71, 72, 73, 250, 212; WHO 13 9, 20, 50-52; WHO 22 and WHO 8 whole subsystems; WHO 25 11-15.

## 6. The four doubts from the PR82 review, re-checked on today's master

| Doubt | State now |
|---|---|
| 2.1 protection 202 vs 302 | fixed: `set_central_mode("protection")` → 302, 202 no longer offered (`heating.py:889-904`, commit `2bc6c32`) |
| 2.2 summer / winter WHAT 0 / 1 | unchanged and correct (`thermal_device.cpp:111-119`); the fixture now cites libqtdevices (`heating.py:889-895`) |
| 2.3 uncaught `ValueError` in MyHOME `async_set_fan_mode` | fixed: `climate.py:488-501` raises `ServiceValidationError` |
| 2.4 standalone zone AUTO returned None | fixed: `*4*311*#Z##` for every zone (`heating.py:791-800`, verified, commit `3014896`) |

## 7. Not verified

* No frame was sent to a gateway or to the firmware emulator in this pass; wire acceptance comes only from the earlier FW audit.
* I did not run the OWNd or MyHOME test suites; the "verified" marks above are `OWNEvent.parse()` / builder outputs run by hand.
* TS10 behaviour is read from the source; I did not build or run libqtdevices.
* Whether any plant emits dimension 13 as a bare digit (M6) or the holiday / weekend WHATs on `#0` (M3, M4) in practice is not
  shown by the TS10 tests or the FW corpus I had; TS10 only proves how BTicino's client would read them.
