# Firmware validation data (2026-10-07)

Evidence behind the WHO 0 / 1 / 4 / 18 / 25 parser and builder changes in this pull request.

| Path | Content |
|---|---|
| `REPORT.md` | Findings, per-frame firmware answers, the fixes and their evidence, assumptions and limits |
| `commands/*.cmds` | The OpenWebNet frames replayed, one per line, per firmware program (`termo` = bt_termo WHO 4, `luci` = bt_luci WHO 1/0/14/15/25/5, `coso` = WHO 2/9, `spv` = bt_supervisione WHO 18, `multi` = bt_multi WHO 22/16, `dev` = bt_device WHO 13) |
| `results/<prog>.tsv` | MyHomeServer1 (mhs1) result per frame: frame, reply (`ACK`, `NACK`, `silent`, or the reply text), SCS bus bodies the program sent (`+`-joined, `-` = none), monitor-port output |
| `results/<prog>_<image>.tsv` | Same lists on the F454 (`f454`), F459, F461 (`f461`) and F450 images; `devP_*` is bt_device rerun with the correct monitor flag |
| `results/*.cl`, `*.stub`, `*.mon` | Raw logs the `.tsv` files are built from: client replies with timestamps, every byte the program sent to the fake bus, monitor-port events |
| `harness/` | The scripts: `run.sh` (inside an `arm32v7/gcc:10` container, chroot into a firmware root), `stub.py` (fake scsserver on port 20001), `client.py`, `mon.py`, `pair.py` (builds the `.tsv`), `compare.py` (image vs mhs1), `batch*.sh` (the runs as executed) |
| `reference/` | `hex2own_corpus.tsv` / `hex2own_firmware.tsv`: OpenWebNet text the same binaries emit for SCS bus frames (the "Emitted" evidence); `SCS_OWN_*_MAP.md`: bus-frame tables derived from the sweeps; `ts10_libqtdevices_comparison.md`: the earlier comparison against BTicino's TS10 client library |

Not included: the firmware images themselves (BTicino property) and the programs' own debug logs.
To reproduce, place the extracted root filesystems next to the harness as `mhs1/`, `f454/`, `F459/`, `f461/`, `F450/`
and run `harness/batch1.sh` … `batch4.sh` from that directory with `WORK=$PWD` (they mount it at `/work` and expect the harness at `$WORK/oracle3/`, its layout when the runs were made).
