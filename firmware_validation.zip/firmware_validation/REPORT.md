# OWNd / MyHOME versus the gateway firmware: emulator validation and exact fixes

Date 2026-10-07. Supersedes the TS10-only match of the same morning (`reference/ts10_libqtdevices_comparison.md`),
which compared against BTicino's 2010 touch-screen client. This pass replays every disputed frame on the
original gateway firmware programs and derives the fixes from what the firmware does.

Every claim below names its evidence. Four kinds are used:

| Label | Meaning |
|---|---|
| **FW** | The exact frame was sent to the original firmware program (ARM binary from the gateway image) running under QEMU in Docker on a fake SCS bus, and its reply (`ACK` = `*#*1##`, `NACK` = `*#*0##`, `silent` = no reply) and the bus frames it emitted were recorded. Files: `results/<prog>[_<tree>].tsv`. |
| **Emitted** | A message the firmware produces for a bus frame, from the 26,810-line corpus `reference/hex2own_corpus.tsv` (built in September from the same binaries) and `reference/hex2own_firmware.tsv`. |
| **Spec** | Legrand/BTicino "Open Web Net Language, WHO = 4" v2.0.0 (2013-11-27), fetched from developer.legrand.com, page numbers given. |
| **TS10** | `libqtdevices` tag `TS10_1_0_23`, `file:line`. Kept only as a second client, not as the reference. |

**Deduction** marks my inference. Everything not marked is quoted from one of the four.

Firmware trees replayed (all under `~/Desktop/test1`): `mhs1` (MyHomeServer1, the six translators `bt_termo`,
`bt_luci`, `coso`, `bt_supervisione`, `bt_multi`, `bt_device`), and the same programs from the `f454`, `F459`,
`f461` and `F450` images where present (section 5). Harness: `oracle3/run.sh`, `stub.py`, `client.py`,
`mon.py`, `pair.py`; command lists `oracle3/*.cmds`; results `results/*.tsv` (columns: command, reply,
bus frames the program sent, monitor-port output). A request frame answered `NACK` while a bus frame was sent
means "the program sent the request and no device answered" (the fake bus answers nothing); the frame column is
the evidence that the request is valid.

Not available in this pass: `openserver` (the router in front of the six programs), the virtual central unit
`bt_thermo_central_unit`, a physical central unit or probe, and the OpenWebNet-Encyclopedia machine KB (the
`openwebnet-mcp` server answered "Machine KB not found" and "not yet replayed" for every frame I asked).

---

## 1. Results in one table

| # | Claim in the morning report | Firmware verdict | Fix |
|---|---|---|---|
| M1 | setpoint mode digit: OWNd/MyHOME send 1 or 2, TS10 sends 3 | **FW**: all three accepted and forwarded as three different bus codes (`90/91/92 ZZ 30 T` for a zone, `C1 12/22/02` for the central); **Spec** p. 8, 23: 1 heating, 2 conditioning, 3 generic | MyHOME patch: write 3 (generic). What the central does with 1 vs 3 is **not provable** here; see 3.1 |
| M2 | `*4*0*Z##` / `*4*1*Z##` read as cool/heat mode | **Spec** p. 13, 16, 19, 63: zone operation mode = season, listed next to the setpoint; **Emitted**: bt_termo prints `*4*1*Z##` with every dimension-12 report; **FW**: as a command it is forwarded (`93 ZZ 30 00/01`) | MyHOME patch: keep AUTO when the zone is AUTO; OWNd gains `message.what` |
| M3 | `*4*115#1102*#0##` read as -10.2 °C | **Spec** p. 56, 64: `115#parameterH`, parameterH = 1101-1103 (program to resume); **FW**: `*4*115#1102*#0##` accepted, bus `C1 14 01 00` | OWNd patch: program number, not temperature |
| M4 | 13xxx / 23xxx read as auto | **Spec** p. 5, 64: holiday days in heating / conditioning mode; **FW**: `*4*13004*#0##` NACK as a command (monitor-only WHAT) | OWNd patch: heat / cool, `holiday_days` property |
| M5 | WHAT 30 / 31 unnamed | **Spec** p. 5, 24, 64: 30 failure discovered, 31 central unit battery KO, 22/23/24 probe status | OWNd patch: named |
| M6 | dimension 13 bare `3` unknown | **Emitted**: mhs1 prints `00, 01, 02, 03, 11, 12, 13, 4, 5, 6, 7, 8`, never a bare `1-3`; **Spec** p. 17, 60 same | **No fix**: OWNd is right, TS10 is merely lenient |
| M7 | alarm arming `*5*36#pwd*0##` | **FW**: no mhs1 program speaks WHO 5 (bt_luci and coso NACK every `*5*` and `*#5*0##`); f454/F459 carry `alarm_central_unit`, not run (no OWN port found in its strings) | none possible on mhs1; OWNd arm/disarm builders remain unverifiable |
| M8 | WHO 0 WHAT 40-44 | **FW** bt_luci: `*0*40#1*W##` ACK `11 00 1C 41`, `41#1` ACK `1C 61`, `42` ACK `1C 00`, `42#1` ACK `1C 21`, `43` ACK `1C FF`, `44` ACK `1C E0`, bare `40`/`41` NACK, `*#0*W##` sends `1C 80`; **Emitted**: `*0*42*31##`, `*0*43*31##`, `*0*45*99##`, `*0*46#9*99##` | OWNd patch: decode 40-46 as programming / lock states |
| M9 | `*18*510#M*W##` has no TS10 counterpart | **FW** bt_supervisione: ACK, bus `D1 A1 02 33 50 1D 09 00`, identical to the reply WHAT 514 request; `*18*59#M*W##` → `50 1C`, `*#18*W*513#M##` → `50 1C` | **No fix**: valid on the firmware; TS10 just never uses it |
| M10 | `*#18*W*1200#type*time##` reply not parsed; MyHOME asks `*#18*W*1200##` | **FW**: `*#18*W*#1200#1*255##` ACK (`D1 A1 02 32 00 02 1D FF`), `#1200#2*255` ACK (`…82 FF`); `*#18*W*1200##` and `1200#1##` NACK with no bus frame | OWNd patch: parse the 1200 reply; MyHOME `sensor.py:512` and `services.py:163` should drop `*#18*W*1200##` (never leaves the gateway) |
| M11 | clock writes with / without timezone | **FW** bt_device: both forms ACK and are echoed on the monitor port (`*#13**#0*12*00*00**##` and `*#13**#0*12*00*00*001##`; date `#1*00*…` and `#1*03*…`; datetime both) | **No fix** |
| M12 | WHO 16 vs WHO 22 sound | **FW** bt_multi: every WHO 16 frame NACK, no bus frame (16 frames tried, including MyHOME's `*#16*0*5##` discovery and the tuner frames of `sound_source.py`); every TS10 WHO 22 frame ACK with a bus frame (amplifier on `90 01 8F 13 + 90 01 81 13`, off `91 01 81 13`, volume `94 01 81 01/11`, set volume `93 01 81 14`, source next/prev `94 01 8F C1/D1`, frequency `94 01 8F A1/B1`, RDS `D1 01 F8 35 01 41/42 04 00`, treble/preset/loud writes) | OWNd needs a WHO 22 module; exact frames in 3.6 |

Beyond the twelve: the TS10-only WHO 1 commands (presets 2-10, step 30/31 with and without `#delta#speed`, timers
11-18, variable timer write `*#1*W*#2*h*m*s##`) are all **FW** ACK on bt_luci with a bus frame, so OWNd now has
builders for them (patch). The TS10 WHO 25 scenario-plus frames 11-15 are **FW** ACK and echoed, so OWNd now
parses and builds them (patch). Dimension 22 (split control) **crashes bt_termo** on mhs1 and f454
(`*#4*#0*22##`, `*#4*23*22##`, `*#4*23*#22*3**1*1##` → segmentation fault, 3 restarts in `out/termo.prog`),
which repeats `reference/SCS_OWN_MAP_bt_termo.md` ("`*#4*40*22##` crashes bt_termo").

---

## 2. What the firmware does with each replayed frame

### 2.1 bt_termo (WHO 4), mhs1 — `results/termo.tsv`, 75 frames; f454 identical (section 5)

Commands (all ACK unless noted):

| Frame | Bus body | Reading |
|---|---|---|
| `*#4*23*#14*0220*1##` / `*2##` / `*3##` | `90 17 30 2C` / `91 17 30 2C` / `92 17 30 2C` | zone setpoint, short frame; the mode digit selects the command code 90/91/92 (`reference/SCS_OWN_MAP_bt_termo.md` section 5) |
| `*#4*#23*#14*0220*1##` / `*2##` / `*3##` | `D1 00 03 02 C2 17 12 2C` / `…22 2C` / `…02 2C` | zone setpoint via the central (address byte 00); digit in the high nibble of byte 7 |
| `*#4*#23#1*#14*0220*3##` | `D1 01 03 02 C2 17 02 2C` | same, via central **1** (TS10's `#Z#N` form, `test_probe_device.cpp:125`) |
| `*#4*#0*#14*0250*1##` / `*2##` / `*3##` | `D1 00 03 02 C1 12 32 00` / `C1 22` / `C1 02` | central setpoint, digit = `12/22/02` |
| `*4*0*23##` / `*4*1*23##` | `93 17 30 01` / `93 17 30 00` | zone command "conditioning" / "heating" |
| `*4*0*#23##` / `*4*1*#23##` | `D1 00 03 02 C1 F1 00 00` / `C1 F0` | same addressed to the central for that zone |
| `*4*311*23##` | **NACK**, nothing | automatic needs `#Z` (FW A3 confirmed again) |
| `*4*311*#23##` / `*4*311*#23#1##` | `D1 00 03 02 C2 17 00 00` / `D1 01 …` | automatic, via central 0 / central 1 |
| `*4*303*23##` / `*4*303*#23#1##` | `93 17 30 0F` / `D1 01 03 02 C2 17 06 00` | off, both forms |
| `*4*302*23##` / `*4*302*#23##` / `*4*102*#23##` / `*4*202*#23##` | `93 17 30 04` / `C2 17 07 00` / `C2 17 17 00` / `C2 17 27 00` | protection, generic / antifreeze / thermal |
| `*4*310*#23##`, `*4*110*#23##` | **NACK** | manual is not a command on this firmware (Spec p. 55: monitor-only) |
| `*4*303*#0##`, `*4*0*#0##`, `*4*1*#0##`, `*4*302*#0##`, `*4*311*#0##` | `C1 06`, `C1 F1`, `C1 F0`, `C1 07`, `C2 00` | the five central commands OWNd `set_central_mode` builds |
| `*4*3113*#0##`, `*4*3209*#0##` | `C1 01 0C`, `C1 03 08` | program 13, scenario 9 |
| `*4*315#3112*#0##`, `*4*33002#3115*#0##`, `*4*33005#3102*#0##` | `C1 04 0B`, `C1 05 02 0E`, `C1 05 05 01` | weekend / holiday with program; the day count is carried (byte 7 = 02 / 05) |
| `*#4*#0*#30*29*08*2026##`, `*#4*#0*#31*23*08##`, `*#4*#0*#32*13*05##` | `C3 1D 08 1A`, `C4 17 08 00`, `C5 0D 05 00` | end date, end time, timed-manual end |
| `*4*312#0220#2*#0#1##`, `*4*312#0220#2*#1#2##` | `D1 01 … C1 09 2C 02`, `D1 02 … C1 09 2C 02` | timed manual, central 1 / central 2 |
| `*4*303*#1#2##`, `*4*1*#1#2##`, `*#4*#1#2*#14*0250*3##` | `D1 02 03 02 C2 01 06 00`, `… C1 F0`, `… C2 01 02 32` | TS10 4-zone addressing `#1#2` = zone 1 of central 2 |
| `*4*115#1102*#0##`, `*4*215#2102*#0##`, `*4*1102*#0##`, `*4*2102*#0##`, `*4*1203*#0##` | `C1 14 01 00`, `C1 24 01 00`, `C1 11 01 00`, `C1 21 01 00`, `C1 13 02 00` | the `#1102` parameter becomes program 02 (byte 7), not a temperature |
| `*4*13004*#0##`, `*4*23004*#0##` | **NACK** | monitor-only WHATs (Spec p. 64) |

Requests (reply NACK = no device on the fake bus; the bus frame proves the request is built):
`*#4*#0##` → `99 00 30 C0`; `*#4*#23#1##` → `D1 01 03 03 C2 17 00 00`; `*#4*23##` → **nothing** (NACK, no frame:
the firmware does not expand the bare zone status request); `*#4*23*11##` → `99 17 30 0B`; `*#4*23*#11*2##` → ACK
`D1 17 03 02 0B 02 00 00`; `*#4*23*15#1##` → `D1 17 03 03 21 01 00 00`; `*#4*23*15##` → `… 21 00 …` (MyHOME's
bare form is also forwarded); `0` / `14` / `12` / `13` / `19` → `99 17 30 00/0E/12/0D/13`; `20` → `A9 17 30 10`;
`7` / `5` → `D1 17 03 03 05/02 00 00 00`; `*#4*23*50##`, `*#4*23*#50*1*2*3##`, `*#4*0##` → NACK, no frame
(BACnet dimensions do not exist on this firmware); dimension 22 → crash (above).

Emitted side (`reference/hex2own_corpus.tsv`, `reference/hex2own_firmware.tsv`): the zone WHATs bt_termo ever prints are
`0, 1, 102, 202, 303, 107, 108, 207, 208, 402, 407, 408, 410, 502, 507, 508, 510, 39, 40, 41-44, 4001#v, 4002#v`
and the artefact `*4*-1*Z##` (406 corpus lines, for an unknown dimension-12 mode byte); `110/111/210/211/310/311`
are never emitted for a zone. `*4*1*Z##` / `*4*0*Z##` always accompany `*#4*Z*12*TTTT*3##` (`reference/SCS_OWN_MAP_bt_termo.md`
section 4, DD = 12: mode byte `F0` → 1, `F1` → 0, `F2` → 102, `F3` → 202, `FF` → 303, `10` → 108, `11` → 107 …).
Dimension 13 values printed: `00` (45), `4` (36), `01`, `02`, `03`, `11`, `12`, `13`, `5`, `6`, `7`, `8` (one each).

### 2.2 bt_luci (WHO 1, 0, 14, 15, 25), mhs1 — `results/luci.tsv`, 48 frames

| Frame | Reply | Bus body |
|---|---|---|
| `*1*2*11##`, `*1*5*11##`, `*1*10*11##` | ACK | `11 00 12 1D` / `4D` / `9D` (dimmer presets, TS10 `setLevel100` path) |
| `*1*30*11##`, `*1*31*11##` | ACK | `11 00 12 03` / `04` |
| `*1*30#20#1*11##`, `*1*31#20#255*11##` | ACK | `D1 11 01 42 0D 03 14 01` / `… 0D 04 14 FF` |
| `*1*11*11##`, `*1*18*11##` | ACK | `11 00 12 16` / `86` (fixed timers) |
| `*1*1#1*11##`, `*1*0#1*11##` | ACK | `D1 11 01 42 0D 00 00 01` / `… 0D 01 00 01` |
| `*1*20*11##`, `*1*9*11##` | ACK | `11 00 12 0B` / `8D` |
| `*#1*11*#1*134*50##` | ACK | `D1 11 01 42 0D 0D 22 32` |
| `*#1*11*#1*100*50##` | **NACK** | nothing (FW A7 again) |
| `*#1*11*#2*0*1*0##` | ACK | `D1 11 01 42 06 00 01 00` (variable timer write) |
| `*#1*11*1##`, `*#1*11*2##`, `*#1*11##` | NACK | `D1 11 01 43 0D 0D 00 00`, `D1 11 01 43 06 00 00 00`, `11 00 15 00` (requests sent, no device) |
| `*0*40#1*11##`, `*0*41#1*11##`, `*0*42*11##`, `*0*42#1*11##`, `*0*43*11##`, `*0*44*11##` | ACK | `11 00 1C 41` / `61` / `00` / `21` / `FF` / `E0` |
| `*0*40*11##`, `*0*41*11##` | NACK | nothing |
| `*0*5*11##`, `*0*31*11##` | silent | `11 00 14 05` ×2 / `11 00 14 1F` ×2 (frame sent twice, no reply; no crash) |
| `*#0*11##` | NACK | `11 00 1C 80` |
| `*25*11#0*11##`, `*25*12*11##`, `*25*13#0#5*11##`, `*25*14#0#5*11##`, `*25*15*11##` | ACK, echoed on monitor | `B1 01 93 00` / `94 00` / `95 40` / `96 40` / `97 00` |
| `*25*21#1*21##` | ACK, echoed | `B2 01 90 01` |
| `*#25*31##`, `*#25*11##` | NACK | `B4 00 90 01`, nothing |
| `*5*36#1234*0##`, `*5*50#1234#11110000*0##`, `*#5*0##`, `*5*1*0##`, `*5*8*0##` | **NACK** | nothing (WHO 5 is not bt_luci's) |
| `*14*1*11##`, `*14*0*11##`, `*15*01*0110##` | ACK | `11 00 10 00`, `11 00 11 00`, `CD 1A 14 01` |

### 2.3 coso (WHO 2, 9), mhs1 — `results/coso.tsv`, 11 frames

`*2*1*11##` → ACK, `11 00 12 0A + 11 00 12 08`, monitor `*2*1000#0*11##` `*2*1000#1*11##`; `*2*2*11##` → `0A + 09`;
`*2*0*11##` → `0A`; `*#2*11##` → ACK `11 00 15 00`; `*#2*11*10##` → ACK `D1 11 01 43 09 00 00 00`;
`*#2*11*#11#001*50##` → ACK `D1 11 01 42 09 39 32 00`, monitor echoes `*#2*11*#11#001#1*50##`; `*9*1*7##` / `*9*0*7##` →
ACK `B0 00 9A 74` / `70`, echoed; `*#9*7##` NACK nothing; `*5*36#1234*0##`, `*#5*0##` NACK nothing.

### 2.4 bt_supervisione (WHO 18), mhs1 — `results/spv.tsv`, 41 frames

`113` / `1134` / `1130` requests → ACK `D1 A1 02 33 00 1D/86/82 00 00`; `#1200#1*255` / `#1200#1*0` / `#1200#2*255` →
ACK `D1 A1 02 32 00 02 1D FF` / `…1D 00` / `…82 FF`; `*#18*51*1200##`, `1200#1##` → **NACK, nothing**;
`54` → ACK `50 18`; `53` → silent `50 17`; `51` → ACK `50 15`; `52#26#9` → silent `50 16 1A 09`;
`*#18*51*511#9#1##` → silent `50 1A 09 01` and `*18*57#9#1*51##` → ACK, same body; `*#18*51*513#9##` → silent `50 1C 09 00`
and `*18*59#9*51##` → ACK, same; `*#18*51*514#9##` → silent `50 1D 09 00` and **`*18*510#9*51##` → ACK, same body**;
`*18*56#9*51##` / `*#18*51*510#9##` → `50 14 09 00`; `*18*58#9*51##` / `*#18*51*512#9##` → `50 1B 09 00`; `*18*53#9*51##` →
`50 11 09 00`; `516` → silent `50 05`, `517#1` → silent `50 06`, `#517#1*1234` → ACK `D1 A1 02 32 50 06 04 D2`;
loads: `*#18*71#0*71##` → ACK `D1 B1 12 33 70 03 00 00` and `*#18*71#0*113##` → ACK `D1 B1 12 33 00 1D 00 00`, while
the TS10 plain-WHERE forms `*#18*71*71##`, `*18*73*71##`, `*18*74*71##`, `*18*73#15*71##`, `*18*75#2*71##`, `72#1`, `73` →
NACK nothing (**deduction**: on this firmware a load actuator must be addressed `7N#0`, as OWNd already does for `7N`);
Stop&Go `*18*26*51##` → ACK `D1 A1 02 32 10 01 04 01`, `*18*21*51##` → `…10 01 02 00`, `*#18*51*250##` → `D1 A1 02 33 10 10 00 00`,
`*#18*51*#212*10##` → `D1 A1 02 32 10 1C 00 0A`, `*#18*51*212##` → `D1 A1 02 33 10 1C 00 00`.

### 2.5 bt_multi (WHO 22 / 16), mhs1 — `results/multi.tsv`, 43 frames

All 16 WHO 16 frames: NACK, no bus frame. WHO 22: `*22*34#4#1*3#1#1##` → ACK `90 01 8F 13 + 90 01 81 13`;
`*22*0#4#1*3#1#1##` → `91 01 81 13`; `*22*3#1*3#1#1##` / `*22*4#1*3#1#1##` → `94 01 81 01` / `11`;
`*#22*3#1#1*#1*20##` → `93 01 81 14`; `*#22*3#1#1*12##` / `*1##` / `*2##` → NACK with request frames `95 01 81 8F` / `95 01 81 00` /
`D1 01 18 33 07 00 00 00`; `*22*35#4#1#1*3#1#0##` → NACK but three frames `A1 0F 81 13 + 90 00 81 13 + 90 01 8F 13`;
`*22*9*2#1##` / `10` → `94 01 8F C1` / `D1`; `*22*5#1*2#1##` / `6#1` → `94 01 8F A1` / `B1`; `*22*33#5*2#1##` → `93 01 8F D4`;
`*#22*2#1*#6*5##` → `93 01 8F C4`; `*22*31*2#1##` / `32` → `D1 01 F8 35 01 41/42 04 00`; `*#22*2#1*5##` / `6` / `13` / `12` →
NACK with `95 01 8F A0` / `C0` / `D1 01 F8 33 03 00 00 00` / `95 01 8F 8F`; `*#22*3#1#1*#19*2##` → `D1 01 18 32 0C 33 00 02`;
`*#22*3#1#1*#20*1##` → `D1 01 18 32 0C 13 00 80`; `*22*40#1*3#1#1##` → `D1 01 18 32 07 41 C0 C0`; `*22*55*3#1#1##` →
`D1 01 18 32 0C 33 00 C1`; area `*22*34#4#1*4#1##` → `90 01 8F 13 + A0 01 81 13`; general `*22*0#4#1*5#3#0#0##` → `B1 00 80 13`.

### 2.6 bt_device (WHO 13), mhs1 — `results/dev.tsv`, 24 frames

Both clock-write forms ACK and echo (TS10 empty-timezone and OWNd filled-timezone, for dimensions 0, 1 and 22).
Requests answered locally: `0` → `*#13**0*12*48*17*000##`, `1` → `*#13**1*03*07*10*2026##`, `9` → `*#13**9*1##`,
`10` → `172*17*0*4`, `11`, `12`, `15` → `200`, `16` → empty, `19` → `0*0*8*17`, `22`, `23` / `24` → empty, `50` → `0*0*0*0`,
`51` → `8*8*8*8`, `52` → `8*8*4*4`, `*#1013*0*1##` → `*#1013**1*0*0*0*0##`; `*#13**#9*1##` ACK; `*#13**20##` silent (no PIC in
the emulator). No bus frame for any of them.

---

## 3. Exact fixes

Two patch files, produced with `git diff` on the clones in `OWNdTS10/` and saved as
this pull request (9 files, +323/-12) and
the companion MyHOME pull request (`climate.py`, +33/-7). OWNd's test suite with the patch:
1239 passed, 2 skipped, 1 failed (`test_metadata.py::test_runtime_version_matches_installed_package`, which
fails identically without the patch because the package is not pip-installed). MyHOME's suite was not run (needs
Home Assistant); `climate.py` compiles.

### 3.1 Setpoint mode digit (M1) — MyHOME `climate.py`

New constant `SETPOINT_WRITE_MODE = CLIMATE_MODE_AUTO` (`climate.py:85` after patch) used in the five
`set_temperature` / `set_central_temperature` calls (lines 572, 582, 597, 609, 618), so every write is
`*#4*W*#14*TTTT*3##`. Evidence: Spec p. 8 and p. 23 define 3 = generic; TS10 writes only 3; the firmware forwards
each digit as a distinct bus code (2.1). **Deduction, not proven**: that the central unit treats 1/2 as a season
change. The patch is the TS10-conformant choice; if the user wants the season forced, keep the old code.

### 3.2 Zone season frame (M2) — MyHOME `climate.py` and OWNd `base.py`

OWNd: `OWNMessage.what` property (raw WHAT). MyHOME: in the `MESSAGE_TYPE_MODE` branch, when `message.what in (0, 1)`,
the entity is not the central, and the current mode is AUTO, the frame is logged as season and the mode is kept
(`climate.py:761-782` after patch). Evidence: Spec p. 13/16/19/63 ("zone operation mode acquire frame" 0 =
conditioning, 1 = heating, given with the setpoint frames); **Emitted**: bt_termo prints `*4*1*Z##` with every
`*#4*Z*12*…*3##` (2.1); TS10 keeps AUTO (`probe_device.cpp:240-253`). **Deduction**: a zone that is HEAT in Home
Assistant (set by a manual setpoint) still flips correctly, because the branch only applies while AUTO.

### 3.3 Holiday plan parameter, holiday ranges, status WHATs (M3, M4, M5) — OWNd `heating.py`

`115#/215#/315#` parameter → `program` (= parameter % 100), log "(program N)", `message_type` stays `hvac_mode`;
`110#T/210#T/310#T/112#T/…` keep the temperature reading. 13xxx → heat, 23xxx → cool, 33xxx → auto, all with
`holiday_days`. 11xx/21xx/31xx → `program`, 12xx/22xx/32xx → `scenario`. WHAT 22/23/24/30/31 get their Spec names.
Tests updated: `tests/test_message_edges.py` (`test_mode_holiday_*`, `test_holiday_plan_parameter_is_a_program_not_a_temperature`,
`test_manual_with_temperature_parameter`).

### 3.4 WHO 0 scenario-module states (M8) — OWNd `scenario.py`

`OWNScenarioEvent` now sets `event` = `launched` for WHAT 1-31, else `programming started / programming stopped /
deleted / locked / unlocked / status 45 / status 46`, with `programming_scenario` from the `#N` parameter. Evidence 2.2.
Builders for `*0*40#N*W##`, `41#N`, `42`, `42#N` are not added: OWNd has no WHO 0 command class today and MyHOME
does not program scenario modules; the frames are in 2.2 if wanted.

### 3.5 WHO 25 scenario plus (TS10 11-15) — OWNd `cen.py`

`OWNScenarioPlusEvent` (`action` on/off/increase/decrease/stop) and `OWNScenarioPlusCommand.turn_on/turn_off/increase/decrease/stop`
building `*25*11#0*W##`, `*25*12*W##`, `*25*13#0#5*W##`, `*25*14#0#5*W##`, `*25*15*W##`; the WHO 25 dispatchers route
WHAT 11-15 to them. Tests in `tests/test_issue_77_firmware_findings.py` updated (the PR 82 rule "any other WHAT is a
bare event" now excludes 11-15). Evidence 2.2 (ACK + monitor echo). The firmware-emitted forms use WHERE `1xx`
(`*25*12*131##`, 64 corpus lines), the TS10 form a plain address; both parse.

### 3.6 Energy (M9, M10) — OWNd `energy.py`, MyHOME `sensor.py` / `services.py`

OWNd: dimension 1200 reply → `message_type = "auto_update_interval"`, `update_interval`, `energy_type`.
MyHOME (not patched, one-line removals): `sensor.py:512` `OWNCommand.parse(f"*#18*{where}*1200##")` and the
`*#18*{addr}*1200##` entries in `services.py:163` send a frame the firmware refuses without a bus frame (2.4); drop
them or replace with `start_sending_instant_power`. `*18*510#M*W##` stays.

### 3.7 WHO 1 builders TS10 has and the firmware accepts — OWNd `lighting.py`

`set_brightness_preset(where, 2..10)`, `step_up/step_down(where[, delta, speed])`, `switch_on_timed(where, 11..18)`,
`set_variable_timer(where, h, m, s)`, `get_variable_timer(where)`. Evidence 2.2.

### 3.8 Sound (M12) — not patched

A WHO 22 module is a new subsystem (amplifier `3#A#P`, area `4#A`, general `5#3#0#0`, source `2#S`); the
firmware-validated frames are listed in 2.5 and TS10's parsers in `media_device.cpp:437-488, 597-636, 885-909,
1150-1211`. MyHOME's media player and `sound_source.py` would have to move from WHO 16 to those frames. **Deduction**:
on an mhs1 plant none of MyHOME's audio commands reach the bus today (16/16 NACK, as FW A9 found with 472 frames).

### 3.9 Not fixable from here

Alarm (M7): no mhs1 program handles WHO 5; the f454/F459 `alarm_central_unit` binary contains the string `*#5*0##` but
no usage text, and I did not find its ports, so it was not run. Load control plain-WHERE forms (TS10 `*18*73*W##` etc.)
are refused by bt_supervisione (2.4); only the `7N#0` forms work, which OWNd already uses for meters but has no
actuator builders for.

---

## 4. The morning report's other items, re-checked

* `*4*311*23##` NACK, `*4*311*#23##` ACK: FW A3 and PR 82 fix 3 confirmed once more.
* `*#4*23*15##` (MyHOME's bare probe request) is forwarded (`D1 17 03 03 21 00 00 00`); TS10's `15#1` adds the probe
  index. Both valid on the firmware.
* `*#4*23##` (bare zone status, Spec p. 19) produces **no bus frame** on mhs1 and f454; `*#4*#23#1##` and the
  per-dimension requests do. MyHOME polls zones with `status(self._full_where)` (`climate.py:416`), so on these
  gateways a plain zone is polled with a frame that never reaches the bus. **Deduction**: the zone still updates from
  the thermostat's own broadcasts; a per-dimension poll (`*#4*Z*0##`, `*12##`, `*13##`, `*14##`, the four frames
  bt_termo itself sends for `*#4*Z##` according to `reference/SCS_OWN_MAP_bt_termo.md` section 5 on the older build) would be the
  firmware-backed form. Not patched: it changes MyHOME's poll-health logic.
* Timed manual and holiday: the day count and hours are carried on the bus (byte 7), so OWNd's `days`/`hours`
  parameters are not dummies on this firmware; TS10's "send 2 then the dates" is one valid way, not the only one.

---

## 5. Other firmware trees

The same command lists were replayed on the translators found in the other images in `test1`
(`harness/batch3.sh`, `batch4.sh`; comparison by `harness/compare.py`, results `results/<prog>_<tree>.tsv`).
"Identical" means reply and bus frames equal to mhs1 for every command.

| Program | f454 | F459 | f461 | F450 |
|---|---|---|---|---|
| bt_termo (WHO 4, 75 frames) | identical 75/75 | identical 75/75 | identical 75/75 | identical 75/75 (incl. the dimension-22 crash) |
| bt_luci (WHO 1/0/14/15/25, 48) | identical 48/48 | identical 48/48 | binary crashes at start under QEMU (SIGSEGV), not comparable | no bt_luci in the image |
| bt_supervisione (WHO 18, 41) | identical 41/41 | identical 41/41 | identical 41/41 | not in the image |
| bt_multi (WHO 22/16, 43) | identical 43/43 | identical 43/43 | aborts at start (`free(): invalid pointer`), not comparable | not in the image |
| coso (WHO 2/9, 11) | did not start with the mhs1 launch line (its `coso_plugins` directory is empty; plugins live elsewhere on these images), not comparable | same | GLib abort at start, not comparable | not in the image |
| bt_device (WHO 13, 24) | answers nothing (RTC ioctl error in the emulator), not comparable | identical except the live values (clock, uptime, IP, DNS: 18/24) | requests answered like mhs1, but every clock write is **NACK** and the log says "Error in opening board description file" (environment, **deduction**: not a protocol difference) | answers nothing (SIGSEGV), not comparable |

So every WHO 4, WHO 18 and WHO 22 verdict in sections 1-3, and every WHO 1 / 0 / 25 verdict, holds on four
firmware generations (MyHomeServer1, F454, F459, F461; F450 for WHO 4), not only on mhs1. No frame behaved
differently on any tree where the program ran. The other images in `test1` (`3488`, `C300x`, `touch`, `ts10`)
contain no OpenWebNet translator binaries (checked with `find` for `bt_*`, `openserver`, `coso`, `scsserver`).

---

## 6. Assumptions and limits, in one list

1. The fake bus never answers, so request frames are judged by the bus frame they produce, not by the NACK.
2. QEMU user-mode emulation of the ARM binaries; three segmentation faults were caused by dimension 22 only.
3. `openserver` is not in the loop: a frame accepted by a translator could still be filtered by the router (the
   earlier audit's "bus level" caveat, unchanged).
4. The Spec is the 2013 v2.0.0 document; the firmware programs are from the images in `test1`; TS10 is a 2010 client.
   Where the three disagree I say which one each fix follows.
5. MyHOME's test suite was not run. OWNd's was, before and after the patch.
6. The MH200N/MyHomeServer1 oracle database of the `openwebnet-mcp` server had none of these frames.
